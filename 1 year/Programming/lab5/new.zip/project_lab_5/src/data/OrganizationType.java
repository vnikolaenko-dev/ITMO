package data;

/**
 * Модель объекта "Тип Организации"
 *
 * @author vnikolaenko
 * @since 1.0
 */
public enum OrganizationType {
    PUBLIC,
    TRUST,
    OPEN_JOINT_STOCK_COMPANY;
}
